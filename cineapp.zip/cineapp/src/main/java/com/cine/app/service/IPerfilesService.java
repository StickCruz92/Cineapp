/**
 * 
 */
package com.cine.app.service;

import com.cine.app.model.Perfil;

/**
 * @author Stick.stivenson
 *
 */
public interface IPerfilesService {
	void guardar(Perfil perfil);
}
