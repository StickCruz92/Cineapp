/**
 * 
 */
package com.cine.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cine.app.model.Perfil;

/**
 * @author Stick.stivenson
 *
 */
public interface PerfilesRepository extends JpaRepository<Perfil, Integer> {

}
