package com.cine.app.service;

import com.cine.app.model.Detalle;

public interface IDetalleService {

	void insertar(Detalle detalle);
	void eliminar(int idDetalle);
	
}
